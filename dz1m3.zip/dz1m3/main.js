// const str = prompt("Enter color , for example: red , blue , green");
//
// console.log(str);
//
// if (str === "red") {
//     bgcolor = "red";
// } else if (str === "green") {
//     bgcolor = "green";
// } else if (str === "blue") {
//     bgcolor = "blue";
// } else {
//     alert ("error , enter blue or red or green ");
// }
//
// document.body.style.backgroundColor = bgcolor;


let color = prompt("Введите цвет (например, red, blue, green):");

if (color) {
    color = color.toLowerCase();
    if (["red", "blue", "green", "yellow", "orange", "purple", "pink"].includes(color)) {
        document.body.style.backgroundColor = color;
        document.getElementById("header").innerHTML = "Фон изменён на " + color;
    } else {
        alert("Ошибка! Введите корректный цвет.");
    }
}